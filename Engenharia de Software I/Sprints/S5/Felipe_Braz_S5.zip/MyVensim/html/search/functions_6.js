var searchData=
[
  ['main_0',['main',['../test_2funcional_2main_8cpp.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'main():&#160;main.cpp'],['../test_2unit_2main_8cpp.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'main():&#160;main.cpp']]],
  ['model_1',['Model',['../class_model.html#ae3b375de5f6df4faf74a95d64748e048',1,'Model::Model()'],['../class_model.html#adb9a3ef8af96767c4ea6cdc8e9c0e26a',1,'Model::Model(const string name, const double time=0.0)'],['../class_model.html#ad8cc8bf11424f2346749c16804559fb0',1,'Model::Model(const Model &amp;m)']]]
];
