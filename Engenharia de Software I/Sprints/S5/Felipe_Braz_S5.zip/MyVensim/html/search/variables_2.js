var searchData=
[
  ['models_0',['models',['../class_model.html#a40dc413265db58fe7a98b2bd4448a1fa',1,'Model']]]
];
