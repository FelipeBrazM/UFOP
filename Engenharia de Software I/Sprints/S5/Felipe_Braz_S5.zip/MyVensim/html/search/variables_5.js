var searchData=
[
  ['systens_0',['systens',['../class_model.html#aca54beb7c03de5a212265e0ca8251338',1,'Model']]]
];
