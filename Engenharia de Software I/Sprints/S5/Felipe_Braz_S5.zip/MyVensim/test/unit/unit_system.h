#ifndef UNIT_SYSTEM_H
#define UNIT_SYSTEM_H

void run_unit_tests_system(void);

void unit_system_constructor(void);
void unit_system_destructor(void);

void unit_system_getName(void);
void unit_system_setName(void);

void unit_system_getValue(void);
void unit_system_setValue(void);

#endif