// Felipe Braz Marques - 22.1.4030

#ifndef UNIT_TESTS_H
#define UNIT_TESTS_H

/**
 * @brief unit testing function
 * 
 */
void unitTest();

#endif