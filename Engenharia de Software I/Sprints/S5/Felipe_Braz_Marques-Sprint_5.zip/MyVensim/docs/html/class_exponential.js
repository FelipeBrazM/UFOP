var class_exponential =
[
    [ "Exponential", "class_exponential.html#a03a6f5cb9706e8641c24f047d6d5ace2", null ],
    [ "execute", "class_exponential.html#ab32cd52ed47f5e3f16cdfe0aa05c94a6", null ]
];