var funcional___tests_8h =
[
    [ "ComplexFunction", "funcional___tests_8h.html#a162a12db8611968bad65dc8834e9d946", null ],
    [ "ExponentialFunction", "funcional___tests_8h.html#ac919bca0ce3ce6cb6b840b7aaf683ad6", null ],
    [ "LogisticFunction", "funcional___tests_8h.html#a2efdfd4bf56d57ffc2465251afdb5f54", null ]
];