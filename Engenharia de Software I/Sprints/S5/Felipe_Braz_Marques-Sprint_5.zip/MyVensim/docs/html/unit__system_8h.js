var unit__system_8h =
[
    [ "run_unit_tests_System", "unit__system_8h.html#ab3d9f7c3d450ff30ca9cf6b51666f701", null ],
    [ "unit_System_constructor", "unit__system_8h.html#a46e097a8a45f48d72634c5dff1f7ca5f", null ],
    [ "unit_System_destructor", "unit__system_8h.html#a6102352f9630ddcf12eb94bc4b558bc1", null ],
    [ "unit_System_getName", "unit__system_8h.html#ac5707e927092753fdf9ffb275f209466", null ],
    [ "unit_System_getValue", "unit__system_8h.html#adeeb73fcb3ab0a36610f3740f85b6eae", null ],
    [ "unit_System_setName", "unit__system_8h.html#ae92753cb0977ecd3217dc3540dc33e87", null ],
    [ "unit_System_setValue", "unit__system_8h.html#a0e0a4c0513e1dbf6487920465ce62b22", null ]
];