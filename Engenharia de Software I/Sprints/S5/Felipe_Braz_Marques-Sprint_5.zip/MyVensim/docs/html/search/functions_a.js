var searchData=
[
  ['testflow_0',['testflow',['../class_testflow.html#a26ea550007525ce342d12eaf5476ea1d',1,'Testflow::Testflow(const string name=&quot;teste&quot;, System *input=NULL, System *output=NULL, double tax=0.0)'],['../class_testflow.html#a26ea550007525ce342d12eaf5476ea1d',1,'Testflow::Testflow(const string name=&quot;teste&quot;, System *input=NULL, System *output=NULL, double tax=0.0)']]]
];
