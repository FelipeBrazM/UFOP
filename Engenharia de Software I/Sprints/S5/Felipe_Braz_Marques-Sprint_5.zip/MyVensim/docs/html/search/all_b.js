var searchData=
[
  ['tax_0',['tax',['../class_flow_impl.html#ac05284681c843b8ad53233b1341552cc',1,'FlowImpl']]],
  ['testflow_1',['testflow',['../class_testflow.html',1,'Testflow'],['../class_testflow.html#a26ea550007525ce342d12eaf5476ea1d',1,'Testflow::Testflow(const string name=&quot;teste&quot;, System *input=NULL, System *output=NULL, double tax=0.0)'],['../class_testflow.html#a26ea550007525ce342d12eaf5476ea1d',1,'Testflow::Testflow(const string name=&quot;teste&quot;, System *input=NULL, System *output=NULL, double tax=0.0)']]]
];
