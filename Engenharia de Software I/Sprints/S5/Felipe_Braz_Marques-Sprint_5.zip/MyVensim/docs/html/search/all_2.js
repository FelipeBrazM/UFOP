var searchData=
[
  ['deleteflow_0',['deleteflow',['../class_model.html#a0aa148138693c6750be8a0490a4585d1',1,'Model::deleteFlow()'],['../class_model_impl.html#af51c7b300b406c20231d29769673300f',1,'ModelImpl::deleteFlow()']]],
  ['deletesystem_1',['deletesystem',['../class_model.html#aa298b862906cf74e2933ab1b8f3f5212',1,'Model::deleteSystem()'],['../class_model_impl.html#a1119617f4c2d551e7841c9460ac1c28a',1,'ModelImpl::deleteSystem()']]]
];
