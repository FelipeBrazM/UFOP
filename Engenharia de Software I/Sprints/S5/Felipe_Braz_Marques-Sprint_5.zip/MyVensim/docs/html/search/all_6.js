var searchData=
[
  ['logistic_0',['logistic',['../class_logistic.html',1,'Logistic'],['../class_logistic.html#a1f6643a6db190356083a8066e28b3b03',1,'Logistic::Logistic()']]],
  ['logisticfunction_1',['logisticfunction',['../funcional___tests_8cpp.html#a2efdfd4bf56d57ffc2465251afdb5f54',1,'LogisticFunction():&#160;funcional_Tests.cpp'],['../funcional___tests_8h.html#a2efdfd4bf56d57ffc2465251afdb5f54',1,'LogisticFunction():&#160;funcional_Tests.cpp']]]
];
