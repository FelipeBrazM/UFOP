var searchData=
[
  ['tax_0',['tax',['../class_flow_impl.html#ac05284681c843b8ad53233b1341552cc',1,'FlowImpl']]]
];
