var class_flow =
[
    [ "~Flow", "class_flow.html#a325d284a50ca3274b126b21f5c39b9af", null ],
    [ "execute", "class_flow.html#a619be0b590c78202127bc6ac7fb04029", null ],
    [ "getName", "class_flow.html#aa91a8025b6dbb27ee5137c7c9ad0c564", null ],
    [ "getSystemInput", "class_flow.html#a2f9936166fba3f5bd28f3d38ecee5f77", null ],
    [ "getSystemOutput", "class_flow.html#a9e6edca166b2d1ba709fb4d7862b4c0f", null ],
    [ "getTax", "class_flow.html#a44b7bfae86125b854612f08f7b129ce1", null ],
    [ "setName", "class_flow.html#a719883d550abcfcb9dfcd4a7e1b86443", null ],
    [ "setSystemInput", "class_flow.html#ab10d20d5f71ac0e4973a03b8a894f13e", null ],
    [ "setSystemOutput", "class_flow.html#a581c6b24176dca0737c2fc6e76ea3dea", null ],
    [ "setTax", "class_flow.html#a6aa1632fb2b9dcfa09720e100dd9af8d", null ]
];