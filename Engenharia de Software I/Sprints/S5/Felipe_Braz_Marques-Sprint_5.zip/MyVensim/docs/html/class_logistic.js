var class_logistic =
[
    [ "Logistic", "class_logistic.html#a1f6643a6db190356083a8066e28b3b03", null ],
    [ "execute", "class_logistic.html#a2e7a34730c59a60b3d9cc65b0b1c0639", null ]
];