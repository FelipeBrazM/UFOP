var hierarchy =
[
    [ "Flow", "class_flow.html", [
      [ "FlowImpl", "class_flow_impl.html", [
        [ "ComplexFlow", "class_complex_flow.html", null ],
        [ "Exponential", "class_exponential.html", null ],
        [ "Logistic", "class_logistic.html", null ],
        [ "Testflow", "class_testflow.html", null ],
        [ "Testflow", "class_testflow.html", null ]
      ] ]
    ] ],
    [ "Model", "class_model.html", [
      [ "ModelImpl", "class_model_impl.html", null ]
    ] ],
    [ "System", "class_system.html", [
      [ "SystemImpl", "class_system_impl.html", null ]
    ] ]
];