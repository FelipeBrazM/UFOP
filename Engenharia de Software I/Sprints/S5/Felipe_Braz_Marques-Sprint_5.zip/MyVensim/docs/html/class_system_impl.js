var class_system_impl =
[
    [ "SystemImpl", "class_system_impl.html#a4cc8c075b21f178e6974e93100791eef", null ],
    [ "SystemImpl", "class_system_impl.html#a6e8460199ac54949b08ecb315fce168b", null ],
    [ "~SystemImpl", "class_system_impl.html#a0cd451779458a7bd7c224a48ed163a9e", null ],
    [ "getName", "class_system_impl.html#a4407f82b905d49335f76c4a18fbfef8d", null ],
    [ "getValue", "class_system_impl.html#aa21b5abc7021e73715c06449fea9e08f", null ],
    [ "setName", "class_system_impl.html#acf5fb86daddb1d3edd3e2e6655091f6f", null ],
    [ "setValue", "class_system_impl.html#a41c3a3164d2c7f4790e2d9cfb8ba6448", null ]
];