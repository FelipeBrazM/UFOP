var unit__system_8cpp =
[
    [ "run_unit_tests_System", "unit__system_8cpp.html#ad467de422f8fd316dde6be5ded75b13b", null ],
    [ "unit_System_constructor", "unit__system_8cpp.html#a46e097a8a45f48d72634c5dff1f7ca5f", null ],
    [ "unit_System_destructor", "unit__system_8cpp.html#a6102352f9630ddcf12eb94bc4b558bc1", null ],
    [ "unit_System_getName", "unit__system_8cpp.html#ac5707e927092753fdf9ffb275f209466", null ],
    [ "unit_System_getValue", "unit__system_8cpp.html#adeeb73fcb3ab0a36610f3740f85b6eae", null ],
    [ "unit_System_setName", "unit__system_8cpp.html#ae92753cb0977ecd3217dc3540dc33e87", null ],
    [ "unit_System_setValue", "unit__system_8cpp.html#a0e0a4c0513e1dbf6487920465ce62b22", null ]
];