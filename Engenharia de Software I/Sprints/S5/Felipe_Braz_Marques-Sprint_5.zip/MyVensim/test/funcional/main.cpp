#include "funcional_Tests.h"

int main(){
    ExponentialFunction();
    LogisticFunction();
    ComplexFunction();
    return 0;
}