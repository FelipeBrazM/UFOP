#ifndef FUNCIONAL_TESTS_H
#define FUNCIONAL_TESTS_H
/**
 * @brief Exponential test function
 * 
 */
void ExponentialFunction();
/**
 * @brief Logistic test function
 * 
 */
void LogisticFunction();
/**
 * @brief Complex test function
 * 
 */
void ComplexFunction();

#endif