#include "unit_flow.h"
#include "unit_system.h"
#include "unit_model.h"

int main(){

    run_unit_tests_Flow();
    run_unit_tests_Model();
    run_unit_tests_System();

    return 0;
}