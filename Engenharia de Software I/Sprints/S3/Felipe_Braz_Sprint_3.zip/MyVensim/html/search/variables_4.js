var searchData=
[
  ['systens_0',['systens',['../class_model.html#a9a7232434bf6cd10436b729fd7814c0e',1,'Model']]]
];
