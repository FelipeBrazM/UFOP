var searchData=
[
  ['flow_0',['Flow',['../class_flow.html#ac9975e144e606242748197798e87dd32',1,'Flow::Flow()'],['../class_flow.html#a13cbc695140b1efe001d047c50f7d8a5',1,'Flow::Flow(System *origin, System *destiny, double(*function)(System *o, System *d), string name)'],['../class_flow.html#a4995436d003d8b696ec5952af104b118',1,'Flow::Flow(const Flow &amp;)']]]
];
