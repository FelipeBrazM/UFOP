var searchData=
[
  ['logistica_0',['logistica',['../funcional__test_8cpp.html#ad7e4a958523100b1eb4aa57e9f9848ea',1,'funcional_test.cpp']]],
  ['logisticalfuncionaltest_1',['logisticalFuncionalTest',['../funcional__test_8cpp.html#a60914db64bde71b56d69320797266c29',1,'logisticalFuncionalTest():&#160;funcional_test.cpp'],['../funcional__test_8h.html#a60914db64bde71b56d69320797266c29',1,'logisticalFuncionalTest():&#160;funcional_test.cpp']]]
];
