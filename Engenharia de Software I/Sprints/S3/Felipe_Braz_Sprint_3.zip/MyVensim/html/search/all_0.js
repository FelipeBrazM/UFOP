var searchData=
[
  ['add_0',['add',['../class_model.html#a187a20b5a900d00628d1111b6346ecbc',1,'Model::add(System *const s)'],['../class_model.html#af07e31f00e151a3851e0bb70e954997f',1,'Model::add(Flow *const f)']]]
];
